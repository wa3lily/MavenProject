package ru.sfedu.mavenproject.enums;

public enum CoverType {
    RIGID_COVER,
    PAPERBACK
}

