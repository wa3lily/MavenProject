package ru.sfedu.mavenproject.enums;

public enum CorrectionsStatus {
    IN_PROCESS,
    WAIT_AUTHOR_AGR,
    WAIT_EDITOR_AGR,
    ACCEPTED
}
