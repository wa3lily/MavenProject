package ru.sfedu.mavenproject.enums;

public enum EmployeeType {
    CHIEF,
    ADMIN,
    MAKER,
    EDITOR
}
