package ru.sfedu.mavenproject.bean.enums;

public enum EmployeeType {
    CHIEF,
    ADMIN,
    MAKER,
    EDITOR
}
