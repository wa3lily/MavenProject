package ru.sfedu.mavenproject.bean.enums;

public enum CoverType {
    RIGID_COVER,
    PAPERBACK
}

