package ru.sfedu.mavenproject.bean.enums;

public enum CorrectionsStatus {
    IN_PROCESS,
    WAIT_AUTHOR_AGR,
    WAIT_EDITOR_AGR,
    ACCEPTED
}
